package com.example.demo.auth;

import java.util.ArrayList;
import java.util.List;

public class Sampler {

	public List<Sample> lister1=new ArrayList<Sample>();
	public List<Sample> lister2=new ArrayList<Sample>();
}
