package com.example.demo.auth;

import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.io.BufferedReader;
import java.io.FileReader;
import java.time.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.example.demo.models.*;

import com.fasterxml.jackson.core.JsonProcessingException;
//add this to database
public class login {

	MongoTemplate mongoTemplate;
	RestTemplate resttemplate=new RestTemplate();
	
	public int yoyo(String name, String password) throws JsonProcessingException
	{
		
		
		user at=new user();
		questions bt=new questions();
		subreddit ct=new subreddit();
		String json="";
	
		at  = resttemplate.getForObject( "http://localhost:8080/finduserbyusername/"+name+"", user.class);
		
		System.out.println("password"+at.getPassword());
		System.out.println(password);
	
		if(at.getPassword().compareTo(password)==0)
		{
			//user authenticated
			//send list of questions and list of subreddits
		
			System.out.println("yes");
		
			 //return json;
			 return 1;
	
		}
		else
		{
			return 0;
			//user not authenticated
		}
		
	}

}