package com.example.demo.auth;

public class Sample {
	
	
	public String question;
	public String url;
	
}