package com.example.demo;

import com.example.demo.models.questions;

public class Wallmodel {
	
	questions a=new questions();
	String subreddit_name="";
	String subreddit_url="";

}
