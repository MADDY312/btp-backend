package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BtpBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(BtpBackendApplication.class, args);
		
	
	}

}
